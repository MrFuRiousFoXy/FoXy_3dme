fx_version 'adamant'
game 'gta5'

lua54 'yes'

author 'FuRious_FoXy'
description 'Texte en 3D au dessus de la tête de votre joueurs lors d\'un /me'

client_script 'c.lua'
server_script 's.lua'

files {
	"index.html",
	"js.js"
}

ui_page {
	'index.html',
}