ESX = nil
TriggerEvent('esx:stgetSharedObject', function(obj) ESX = obj end)

RegisterCommand('me', function(source, args, rawCommand)
	if source == 0 or source == "Console" then return end

	args = table.concat(args, ' ')
	TriggerClientEvent('3dme:client:triggerDisplay', -1, source, args, "me")
	sendToDiscord1('Test', '[ME] ' ..GetPlayerName(source).. ' a utilisé le /me [ID] : '..source.. ' pour écrire : ' ..args..'', 3145658)
end, false)

RegisterCommand('do', function(source, args, rawCommand)
	if source == 0 then return end

	args = table.concat(args, ' ')
	TriggerClientEvent('3dme:client:triggerDisplay', -1, source, args, "do")
		sendToDiscord2('Test', '[DO] '..GetPlayerName(source).. ' a utilisé le /do [ID] : '..source..' pour écrire :' ..args..'', 3145658)
end, false)

function sendToDiscord1 (name,message,color)
	date_local1 = os.date('%H:%M:%S', os.time())
	local date_local = date_local1
	local DiscordWebHook = "https://discordapp.com/api/webhooks/799862972846833735/2oFhvo4iV58XFioRZxhm4GTruC3mfzQC7dTiWXcPMNruR6ppKBFqaw_PeE0eddRdOBwl"
	-- Modify here your discordWebHook username = name, content = message,embeds = embeds
  
  local embeds = {
	  {
		  ["title"]=message,
		  ["type"]="rich",
		  ["color"] =color,
		  ["footer"]=  {
			  ["text"]= "Heure: " ..date_local.. "",
		 },
	  }
  }
  
	if message == nil or message == '' then return FALSE end
	PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = name,embeds = embeds}), { ['Content-Type'] = 'application/json' })
end

function sendToDiscord2 (name,message,color)
	date_local1 = os.date('%H:%M:%S', os.time())
	local date_local = date_local1
	local DiscordWebHook = "https://discordapp.com/api/webhooks/799862972846833735/2oFhvo4iV58XFioRZxhm4GTruC3mfzQC7dTiWXcPMNruR6ppKBFqaw_PeE0eddRdOBwl"
	-- Modify here your discordWebHook username = name, content = message,embeds = embeds
  
  local embeds = {
	  {
		  ["title"]=message,
		  ["type"]="rich",
		  ["color"] =color,
		  ["footer"]=  {
			  ["text"]= "Heure: " ..date_local.. "",
		 },
	  }
  }
  
	if message == nil or message == '' then return FALSE end
	PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = name,embeds = embeds}), { ['Content-Type'] = 'application/json' })
end