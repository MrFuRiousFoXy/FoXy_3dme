##-- INFORMATIONS --##

/me - Mettra un texte sur votre personnage pendant x secondes.
L’heure d’affichage, la couleur et la police peuvent être modifiées à votre goût, 


##-- SCREENSHOT --## 

https://cdn.discordapp.com/attachments/1172979502872264756/1172983376790163546/image.png?ex=65624ce6&is=654fd7e6&hm=4694ee068144fdea50d0e097c68c92f80080e8380c3885104bd75eb80692373f&


##-- DISCORD Scripts --## 

https://discord.gg/xfKXf4ww


Développer par FuRious_FoXy 


